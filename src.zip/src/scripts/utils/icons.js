import cartSvg from "../../assets/images/Cart.svg";
import accountSvg from "../../assets/images/Account.svg";
import searchSvg from "../../assets/images/Search.svg";
import menuSvg from "../../assets/images/Menu.svg";

export const icons = {
  cart: cartSvg,
  account: accountSvg,
  search: searchSvg,
  menu: menuSvg,
};
